package contactApp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class ContactTest {
	
	@Test
	void testContactNullArguments() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact(null, null, null, null, null);
		});
	}
	
	@Test
	void testContactAndGetters() {
		Contact contact = new Contact("123456", "James", "Lightner", "8605555555", "123 Everywhere Rd.");
		assertTrue(contact.getName().equals("James Lightner"));
		assertTrue(contact.getPhoneNumber().equals("8605555555"));
		assertTrue(contact.getContactAddress().equals("123 Everywhere Rd."));
		assertTrue(contact.getContactID().equals("123456"));
	}
	
	@Test
	void testSetFirstAndLastName() {
		Contact contact = new Contact("123456", "James", "Lightner", "8605555555", "123 Everywhere Rd.");
		contact.setFirstName("James");
		contact.setLastName("Lightner");
		assertTrue(contact.getName().equals("James Lightner"));
	}
	
	@Test
	void testSetPhoneNumberAndAddress() {
		Contact contact = new Contact("123456", "James", "Lightner", "8605555555", "123 Everywhere Rd.");
		contact.setPhoneNumber("8605555555");
		contact.setContactAddress("123 Everywhere Rd.");
		assertTrue(contact.getPhoneNumber().equals("8605555555"));
		assertTrue(contact.getContactAddress().equals("123 Everywhere Rd."));
	}
	
	@Test
	void testNullSetAttributes() {
		Contact contact = new Contact("123456", "James", "Lightner", "8605555555", "123 Everywhere Rd.");
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setFirstName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setLastName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setContactAddress(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setPhoneNumber(null);
		});
	}
	
	@Test
	void testAllGetters() {
		Contact contact = new Contact("123456", "James", "Lightner", "8605555555", "123 Everywhere Rd.");
		assertTrue(contact.getName().equals("James Lightner"));
		assertTrue(contact.getContactID().equals("123456"));
		assertTrue(contact.getPhoneNumber().equals("8605555555"));
		assertTrue(contact.getContactAddress().equals("123 Everywhere Rd."));
	}
}
